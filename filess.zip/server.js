import express, { text } from "express";
import multer from "multer";
import pkg from "pg";
import { fileURLToPath } from "url";
import { dirname } from "path";
import * as fs from "fs";
import { JSDOM } from "jsdom";
import { Document, Packer, Paragraph, TextRun } from "docx";
import crypto from "crypto";

const __filename = fileURLToPath(import.meta.url);
const __dirname = dirname(__filename);
const { Client } = pkg;
const app = express();
const sessionTokens = {};

const serverConfig = {
	ip: {
		buhgalteriya: "192.168.13.16",
		servernaya: "192.168.0.60",
		home: "192.168.0.105",
		officeWifi: "10.10.10.211"
	},
	port: 5500,
};

const currentDEVIP = serverConfig.ip.officeWifi;

// Настройка загрузки файлов с фронта на бек
const storage = multer.diskStorage({
    destination: (_, __, callback) => {
        callback(null, "./uploads");
    },
    filename: (_, file, callback) => {
        callback(null, `${Date.now()}_${file.originalname}`);
    },
});

const upload = multer({ storage: storage, limits: { fileSize: 1e10 } });

// Настройка получения запросов с фронта на бек
app.use(express.json());

// Чтение всей директории с файлами
app.use(express.static(__dirname));

app.use((err, req, res, next) => {
    console.error("Произошла ошибка:", err.message);
    res.status(500).send("Internal Server Error");
});

// Запуск сервера Node.JS
app.listen(serverConfig.port, currentDEVIP, (err) => {
	if (err) {
		console.log(serverConfig.port, currentDEVIP);
		console.log(err);
	} else {
		console.log(`Server started on ${currentDEVIP}:${serverConfig.port}`);
	}
});

// Вход на первичную страницу
app.get("/", (req, res) => {
	console.log("Открыта главная страница")
	res.sendFile(__dirname + "/index.html");
});

app.get("/incoming-mail", (req, res) => {
	res.sendFile(__dirname + "/incoming-mail.html");
});

// Запрос на сохранение данных с фронта
app.post("/save-data", async (req, res) => {
    console.log("Полученные данные:", req.body);
    if (!req.body) {
        return res.status(400).send("Empty body");
    }

    const token = req.body.token; // Токен должен быть передан в теле запроса

    if (!token || !sessionTokens[token]) {
        return res.status(403).send("Invalid or expired token.");
    }

    let dbStatus = false;
    try {
        await setDataToBase(req.body); // Сохранение данных в базу
        dbStatus = true;
    } catch (error) {
        console.error("Error saving to database:", error);
        dbStatus = false;
    }

    try {
        const filename = convertDataToDocx(req.body, token); // Создание документа
        res.send({ DB: dbStatus, Docx: true, filename, dataText: req.body });
    } catch (error) {
        console.error("Error generating document:", error);
        res.send({ DB: dbStatus, Docx: false });
    }
});


//Запрос авторизации с фронта
app.post("/get-login", async (req, res) => {
	if (!req.body) {
		return res.sendStatus(400);
	}
	// возвращаемые параметры на фронт
	let signIn = {
		loginIsPossible: false,
		username: "",
		isAdmin: false,
	};
	const reqData = req.body;
	const resData = await getLoginFromDataBase(reqData);

	// Проверка правильности логина/пароля
	if (resData.username === reqData.username && resData.password === reqData.password) {
		signIn.loginIsPossible = true;
		signIn.username = resData.username;
	}
	if (resData.isAdmin) {
		signIn.isAdmin = true;
	}

	// Ответ на фронт о возможности авторизации
	res.send(signIn).end();
});

app.get("/download", async (req, res) => {
    try {
        const token = req.query.token;
        const isValid = await validateToken(token);

        if (!isValid) {
            return res.status(403).send("Invalid or expired token.");
        }

        const filename = `document_${token}.docx`;
        const filePath = `${__dirname}/docs/${filename}`;

        if (fs.existsSync(filePath)) {
            res.download(filePath, (err) => {
                if (err) {
                    console.error("Error sending file:", err);
                    res.status(500).send("Error sending file.");
                }
            });
        } else {
            res.status(404).send("File not found.");
        }
    } catch (error) {
        console.error("Error handling file download:", error);
        res.status(500).send("Internal server error.");
    }
});


app.get("/generate-token", async (req, res) => {
    const username = req.query.username || "guest"; // Получить имя пользователя
    try {
        const token = await generateTokenForUser(username);
        res.json({ token });
    } catch (error) {
        res.status(500).send("Failed to generate token.");
    }
});

async function generateTokenForUser(username) {
    const token = crypto.randomBytes(16).toString("hex");
    return await saveTokenToDatabase(username, token);
}


// Конвертация данных с фронта в DocX документ
function parseHtmlToDocxChildren(html) {
    const dom = new JSDOM(html);
    const document = dom.window.document;
    const children = [];

    document.body.childNodes.forEach((node) => {
        if (node.nodeType === 3) {
            // Текстовый узел
            children.push(new TextRun({ text: node.textContent.trim(), break: 1 }));
        } else if (node.nodeName === "P") {
            // Абзацы
            children.push(
                new Paragraph({
                    children: Array.from(node.childNodes).map((child) =>
                        new TextRun({ text: child.textContent.trim() })
                    ),
                })
            );
        } else if (node.nodeName === "UL" || node.nodeName === "OL") {
            // Списки
            node.childNodes.forEach((li) => {
                if (li.nodeName === "LI") {
                    children.push(
                        new Paragraph({
                            text: li.textContent.trim(),
                            bullet: node.nodeName === "UL" ? { level: 0 } : undefined,
                            numbering: node.nodeName === "OL" ? { reference: "numbering", level: 0 } : undefined,
                        })
                    );
                }
            });
        }
    });

    return children;
}

function convertDataToDocx(data, token) {
    const sender = data.companySender;
    const receiver = data.companyReceiver;
    const receiverName = data.receiverName;
    const theme = data.letterTheme;
    const letterHTML = data.letterText;
    const user = data.currentUser;
    const date = data.dateField;

    try {
        const doc = new Document({
            sections: [
                {
                    properties: {},
                    children: [
                        new Paragraph({
                            children: [
                                new TextRun({ text: `Sender: ${sender}`, bold: true }),
                                new TextRun(`\nReceiver: ${receiver}`),
                                new TextRun(`\nTheme: ${theme}`),
                                new TextRun(`\nDate: ${date}`),
                            ],
                        }),
                        ...parseHtmlToDocxChildren(letterHTML),
                    ],
                },
            ],
        });

        const outputPath = `docs/document_${token}.docx`;
        Packer.toBuffer(doc)
            .then((buffer) => {
                fs.writeFileSync(outputPath, buffer);
                console.log("Document created successfully at:", outputPath);
            })
            .catch((err) => {
                throw new Error("Error generating document buffer: " + err.message);
            });

        return outputPath;
    } catch (error) {
        console.error("Error generating document:", error.message);
        throw error;
    }
}



//PostgreSQL connection
const client = new Client({
 	host: currentDEVIP,
 	port: 5501,
 	database: "postgres",
 	user: "postgres",
 	password: "Es12345678",
});
await client.connect();

// Запись данных письма в базу
async function setDataToBase(data) {
	const lastId = await getCurrentLastId();
	const newId = Number(lastId.rows[0].max) + 1;
	const sql = `INSERT INTO "post" ("id", "sender", "reciever", "date", "text", "user", "theme") VALUES ('${newId}', '${data.companySender}', '${data.companyReciever}', '${data.dateField}', '${data.letterText}', '${data.currentUser}', '${data.letteTheme}')`;
	return client.query(sql);
}

async function saveTokenToDatabase(username, token) {
    try {
        const sql = `
            INSERT INTO "user_tokens" ("token", "username", "created_at")
            VALUES ($1, $2, NOW())
            ON CONFLICT ("username") DO UPDATE 
            SET "token" = $1, "created_at" = NOW();
        `;
        await client.query(sql, [token, username]);
        return token;
    } catch (error) {
        console.error("Error saving token to database:", error);
        throw new Error("Failed to save token");
    }
}

async function validateToken(token) {
    try {
        const sql = `SELECT * FROM "user_tokens" WHERE "token" = $1`;
        const result = await client.query(sql, [token]);
        return result.rows.length > 0;
    } catch (error) {
        console.error("Error validating token:", error);
        throw new Error("Failed to validate token");
    }
}

// Забираем корректный ID из базы
async function getCurrentLastId() {
	const sql = `SELECT MAX(id) FROM "post"`;
	return client.query(sql);
}

// Чтение данных о логине/пароле из базы
async function getLoginFromDataBase(data) {
	const sqlLogin = `SELECT * FROM "users" WHERE "username"  LIKE '${data.username}'`;
	const prepareData = await client.query(sqlLogin);
	if (prepareData.rowCount === 0) {
		return [{ username: "", isAdmin: "false", password: "", name: "" }];
	}
	const userData = prepareData.rows;
	return userData[0];
}